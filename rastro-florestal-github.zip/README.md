# Rastro Florestal

Protótipo funcional local das três telas do produtor: **Meus registros → Novo registro → Editar registro**. React, Vite e IndexedDB. Não requer conta, backend, hospedagem ou chave de API.

O visual de uso no campo já está aplicado: fundo claro, verde profundo, detalhe de areia na marca, títulos e campos maiores, bordas fortes e ações largas. `src/campo.css` adapta os componentes de `src/style.css`. As telas continuam navegáveis separadamente; os HTMLs de estudo não fazem parte do aplicativo. A leitura sob sol e as permissões reais de câmera/GPS devem ser conferidas no aparelho.

As pastas `integracoes/banco-de-dados/` e `integracoes/ia-geoespacial/` contêm os contextos para as outras frentes da equipe. Seus contratos são propostas para discussão; ainda não há conexão remota implementada.

## Executar

Requisitos: Node.js 20.19+ ou 22.12+ (recomendado 22/24), npm e navegador atual (Chrome, Edge ou Firefox). A instalação inicial precisa de internet.

Abra um terminal nesta pasta e execute:

```powershell
npm install
npm run dev
```

Abra **http://127.0.0.1:5173**. O comando `dev` compila e serve a versão local, evitando depender da pré-otimização do servidor de desenvolvimento em ambientes Windows restritos. Após editar o código, encerre e execute o comando novamente. A porta é fixa; se estiver ocupada, encerre o outro servidor antes. Mantenha essa mesma URL, navegador e perfil para reencontrar seus registros. Não alterne entre `localhost` e `127.0.0.1`: são origens diferentes.

Após instalar, o aplicativo funciona sem internet enquanto o servidor local estiver rodando. Todas as fontes, ícones, scripts e imagens usados são locais. Para apresentação com a versão de produção:

```powershell
npm run build
npm run preview
```

O preview usa a mesma origem e preserva o acesso ao IndexedDB. Encerre o servidor de desenvolvimento antes de iniciar o preview. Fechar e reabrir o navegador preserva os registros; para abrir o aplicativo novamente, mantenha o servidor iniciado. Não abra `index.html` diretamente pelo explorador.

## Abrir no celular pela rede local

1. Conecte notebook e celular ao mesmo Wi-Fi.
2. Encerre o servidor atual com Ctrl+C e execute `npm run mobile` na pasta do projeto.
3. O Vite mostra os endereços **Network**. Abra no navegador do celular o endereço da rede Wi-Fi do notebook, por exemplo `http://192.168.1.10:5173` (substitua pelo IP mostrado).
4. Mantenha o terminal e o notebook ligados. Se o Windows pedir acesso à rede, permita somente na rede privada de confiança. Redes de convidados podem bloquear comunicação entre dispositivos.

O comando `mobile` expõe o protótipo aos dispositivos da rede local; use apenas em rede de confiança. Não há autenticação. Por HTTP no IP da rede, navegadores móveis bloqueiam a câmera integrada (`getUserMedia`) e a geolocalização. O botão **Abrir câmera** passa a usar o seletor nativo (`capture="environment"`) nesse caso; o comportamento depende do aparelho e pode oferecer uma escolha de arquivos. Use o HTTPS local abaixo para câmera integrada e localização real. Sem HTTPS, ainda é possível selecionar uma foto, usar demonstração ou salvar sem localização.

Cada navegador/dispositivo tem seu próprio IndexedDB. O celular não acessa os registros salvos no navegador do notebook. Trocar o IP do notebook também muda a origem e o conjunto de dados acessível. Para apenas visualizar o layout móvel no notebook, use o modo de dispositivo das ferramentas do navegador; isso mantém a origem local.

## HTTPS local: câmera e localização no iPhone e Android

Não exige hospedagem, túnel, conta nem internet depois da instalação. O certificado é criado neste notebook e precisa ser instalado **uma vez por aparelho de teste**. Nenhuma configuração de confiança é alterada automaticamente.

No PowerShell, na pasta do projeto:

```powershell
npm.cmd install
npm.cmd run mobile:https
```

O terminal mostra dois endereços. Exemplo com o IP `192.168.1.3`:

- **Preparar o certificado:** `http://192.168.1.3:5175`.
- **Aplicativo seguro:** `https://192.168.1.3:8443`.

A porta 5175 serve apenas instruções e o certificado público. Não disponibiliza o código, as chaves ou os dados do aplicativo. A porta 8443 serve somente a pasta compilada `dist`. O servidor se vincula ao IP privado selecionado. Caso haja várias interfaces, escolha o IP da rede Wi-Fi:

```powershell
npm.cmd run mobile:https -- 192.168.1.3
```

Mantenha notebook e celular na mesma rede. Se necessário, autorize no Windows as portas 8443 e 5175 somente para sua rede privada, pelo aviso de acesso do Node. O servidor HTTP anterior na porta 5173 pode continuar rodando.

### iPhone / iPad

1. No Safari, abra a página **Preparar o certificado** e toque em **Baixar certificado · iPhone**. Compare a impressão SHA-256 com a que aparece no terminal do notebook. Autorize o download do perfil quando o sistema solicitar.
2. Em **Ajustes → Geral → VPN e Gerenciamento de Dispositivo**, abra o perfil **Rastro Florestal Local CA** e instale. O aparelho pode solicitar seu código de desbloqueio.
3. Em **Ajustes → Geral → Sobre → Ajustes de Confiança de Certificados**, habilite confiança para **Rastro Florestal Local CA**. Instalar o perfil por si só não habilita confiança SSL.
4. Abra o endereço **Aplicativo seguro** no Safari. Ele deve abrir sem alerta de certificado. Se houver alerta, confira a instalação, a confiança, o IP e a data do aparelho antes de continuar.
5. Toque em **Abrir câmera** e permita acesso. Para GPS, selecione **Localização atual do dispositivo**, tire a foto e permita acesso. Confira também **Ajustes → Privacidade e Segurança → Serviços de Localização** e a permissão do Safari; habilite localização precisa para o teste se desejar. Permissões do site podem ser ajustadas no menu do Safari.

Referência: [Apple — confiar em perfis de certificado instalados manualmente](https://support.apple.com/pt-br/102390).

### Android

1. Abra **Preparar o certificado** e baixe a opção Android.
2. Em **Configurações → Segurança e privacidade → Mais configurações de segurança → Criptografia e credenciais → Instalar um certificado → Certificado CA**, escolha `rastro-florestal-ca.crt`. O caminho varia conforme o fabricante; pesquise por **certificado CA** nas configurações.
3. Abra o endereço HTTPS no Chrome e permita câmera e localização. O GPS do sistema e as permissões de câmera/localização do navegador também precisam estar habilitados.

Referência: [Google — adicionar e remover certificados](https://support.google.com/pixelphone/answer/2844832?hl=pt-BR).

### Persistência, certificados e outros aparelhos

- O HTTPS é uma origem diferente do HTTP. Registros antigos continuam no endereço HTTP anterior; não são migrados automaticamente. Cada aparelho/navegador tem seus próprios registros.
- Repita a instalação do mesmo certificado público nos demais aparelhos de teste que você controla. Dispositivos gerenciados por empresa/escola podem impedir a instalação. A aplicação não contorna essas políticas.
- Chaves ficam em `.local-https/`, excluído do Git e do ZIP de entrega. Nunca envie os arquivos `.key` ao GitHub nem aos celulares. O certificado raiz fica válido por um ano e o certificado do servidor por 90 dias; o servidor renova seu certificado quando necessário, preservando a autoridade local. Se o IP mudar, reinicie o comando: o certificado do servidor é atualizado e você usa o novo endereço.
- A confiança em uma autoridade certificadora permite validar certificados assinados por ela, não apenas uma página. Guarde as chaves e instale somente nos aparelhos de teste. Ao concluir, remova **Rastro Florestal Local CA** do aparelho se não for continuar usando. O script não instala uma autoridade no Windows nem muda políticas do navegador.
- Câmera e GPS reais exigem permissão do usuário e um contexto seguro. A captura é feita pelo vídeo da câmera dentro do aplicativo, sem seleção de fotos existentes.

## Roteiro de demonstração (5 minutos)

1. Ative **Modo demonstração**. Toque no **+**.
2. Digite o nome do registro, o produtor e a espécie. Em **Tirar foto antes**, use **Abrir câmera → Capturar foto**. No modo demonstração, selecione **Local A** e salve. A localização simulada fica identificada; a foto precisa ser tirada pela câmera.
3. Adicione outro produto se desejar. Clique em **Salvar registro**: o aplicativo confirma a gravação e retorna à lista. A falta de fotos posteriores mantém o registro como rascunho.
4. Abra o cartão. Altere o nome e clique em **Salvar nome**. Produtor, espécies e evidências anteriores permanecem em consulta.
5. Na foto posterior, tire uma nova foto pela câmera e escolha o **Local B** de demonstração. A diferença calculada de aproximadamente 556 m gera um aviso para conferência.
6. Use **Ver tentativas e locais** para consultar as imagens, origem, posições e horários. Acrescente tentativas até **3 de 3** em uma etapa. O botão fica bloqueado; a outra etapa mantém seu contador independente.
7. Atualize a página, abra novamente o cartão e confira que fotos, nome, histórico e limite continuam preservados.

Para registrar uma foto, use **Abrir câmera → Capturar foto**. Não é possível escolher uma foto da galeria ou do computador. Fotos de exemplo anteriormente salvas permanecem identificadas no histórico.

## Regras e limitações

- A primeira foto é a tentativa 1 de 3. Cancelar o modal ou falhar ao obter imagem não gasta tentativa. Em um novo registro, as fotos são provisórias até clicar em **Salvar registro**; sair antes disso pede confirmação. Registros salvos podem receber novas evidências, sem alteração de produtor ou espécie.
- Nome do registro e produtor são obrigatórios. Espécie e fotos podem ser completadas antes do primeiro salvamento ou permanecer incompletas. Depois de salvo, espécie e produtor não podem ser corrigidos, conforme o escopo. Evidências completas exigem espécie e pelo menos uma foto com localização em cada etapa de cada produto.
- As imagens originais ficam como bytes `ArrayBuffer` e tipo MIME no IndexedDB, junto aos metadados. A interface reconstrói o `Blob` para exibição. Isso evita falhas de preparação de Blob/File em navegadores WebKit; fotos antigas armazenadas como Blob continuam legíveis. Não há armazenamento de fotos em localStorage. Inclusões são transações atômicas, inclusive para abas concorrentes; identidade estável impede que a mesma tentativa conte duas vezes.
- O navegador pode negar câmera/localização. Em localhost/loopback essas APIs funcionam em contexto seguro, mas dependem do navegador e das permissões. O notebook pode oferecer localização aproximada. A posição tem horário e precisão; nenhuma posição antiga é reutilizada silenciosamente. Sem posição, é possível salvar uma evidência explicitamente incompleta e depois incluir uma nova tentativa. Essa inclusão sem localização conta como tentativa salva.
- Fotos importadas em versões anteriores indicam a posição do dispositivo **na inclusão**, que não comprova o local ou horário da captura original. Não extraímos GPS EXIF. Fotos de câmera são capturadas pelo aplicativo; coordenadas de demonstração são escolhidas antes de salvar e ficam identificadas para sempre naquela tentativa. Ativar/desativar o modo não altera dados já salvos.
- O alerta usa a distância de Haversine e compara a tentativa exibida com todas as outras do produto que tenham a mesma origem de localização. Dispara quando a distância supera **100 metros + a soma das precisões** das duas posições. Ajuste `ALERT_DISTANCE_M` em `src/store.js` para outro critério. Não compara simulação com GPS real, nem classifica diferenças como fraude ou ilegalidade. Fotos e histórico continuam acessíveis para consulta. A comparação não comprova legalidade ou autenticidade.
- Dados ficam restritos a este perfil e origem. Limpar dados do navegador, usar janela privada, remover o perfil ou perder o dispositivo pode apagar os registros. Não há backup, sincronização, autenticação ou proteção contra alteração pelo próprio usuário nas ferramentas do navegador. Este é um protótipo para demonstração.
- Não há limite de tamanho artificial para as fotos; espaço e desempenho dependem do navegador. Erros de quota/transação são exibidos sem afirmar que a gravação ocorreu.

## Verificação técnica

### Onde entender o código

- `src/main.jsx`: componentes das três telas e dos modais; as funções comentadas explicam a diferença entre rascunho em memória e registro persistido, o ciclo da câmera e a posição por tentativa.
- `src/store.js`: persistência no IndexedDB, identidades, transações atômicas, histórico, limite de envios e comparação geográfica. As regras ficam nesta camada para não depender somente dos botões da interface.
- `scripts/https-local.mjs`: servidores locais de aplicativo e de preparação do certificado; os comentários explicam quais arquivos cada porta pode servir.
- `scripts/local-certificate.mjs`: geração e reutilização dos certificados, validade, renovação e proteção das chaves privadas.
- `src/store.test.js` e `scripts/local-certificate.test.js`: exemplos executáveis das regras de persistência, concorrência, distâncias e certificados.

Os comentários descrevem responsabilidades e motivos das decisões. Não representam uma integração já existente com backend ou IA: essas frentes ainda serão desenvolvidas. O tema de campo está aplicado em `src/campo.css`.

```powershell
npm test
npm run build
```

Os testes usam IndexedDB em memória para validar persistência de Blob, histórico, limite atômico com gravações concorrentes, idempotência, contadores independentes, códigos únicos e cálculo dos alertas. As permissões reais de câmera/GPS dependem do dispositivo utilizado na apresentação.

